package com.moxmixed.app.util

import com.moxmixed.app.BuildConfig

actual fun appVersionLabel(): String =
    "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"
