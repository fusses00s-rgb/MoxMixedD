package com.moxmixed.app.util

import android.app.Application
import io.ktor.client.request.post
import io.ktor.http.HttpStatusCode
import com.moxmixed.app.di.AppConfig
import com.moxmixed.app.di.databaseModule
import com.moxmixed.app.di.platformModule
import com.moxmixed.app.di.sharedModule
import com.moxmixed.app.di.viewModelModule
import com.moxmixed.app.db.DatabaseDriverFactory
import com.moxmixed.app.ktor.createHttpClient
import com.moxmixed.app.auth.GoogleCredentials
import com.moxmixed.app.auth.NoGoogleCredentials
import com.moxmixed.app.auth.AppleCredentials
import com.moxmixed.app.auth.NoAppleCredentials
import com.moxmixed.app.notification.AndroidDailyReminders
import com.moxmixed.app.notification.DailyReminders
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import org.koin.dsl.module

/**
 * Test Application for Android Instrumented Tests
 * Configures Koin with test-specific dependencies and clean database setup
 */
class TestApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        startKoin {
            androidLogger()
            androidContext(this@TestApplication)

            modules(
                // Platform-specific module (provides PlatformDataStore, etc.)
                platformModule(),

                // Database module with fresh driver factory
                databaseModule(DatabaseDriverFactory(this@TestApplication)),

                // Shared module configured to point to local server
                sharedModule(
                    AppConfig(
                        serverHost = TestServer.host,
                        serverPort = TestServer.port,
                    )
                ),

                // Platform bindings that production wires up in PosterApplication
                // because they need a Context. Sign-in providers are no-ops in
                // tests: the suite has no browser and no Play Services account.
                module {
                    single<GoogleCredentials> { NoGoogleCredentials }
                    single<AppleCredentials> { NoAppleCredentials }
                    single<DailyReminders> { AndroidDailyReminders(this@TestApplication) }
                },

                // The real ViewModel graph, so tests exercise production wiring.
                viewModelModule()
            )
        }

    }
}

/**
 * Puts the backend into a known state before a class runs.
 *
 * A bad *response* already said so plainly. A backend that is not listening at
 * all did not: the connection failure escaped this function, out through the
 * runner, and the instrumentation reported "Process crashed before executing
 * the test(s)" with a stack trace of coroutine internals. That message is
 * indistinguishable from the run-voiding crash under load recorded in BUGS.md,
 * which is how an afternoon goes into looking for a race that was a stopped
 * server. Both cases now say the same short thing.
 */
internal fun applyServerFixtures() {
    kotlinx.coroutines.runBlocking {
        val response = try {
            createHttpClient(TestServer.host, TestServer.port).use { httpClient ->
                httpClient.post("debug/fixtures/integration")
            }
        } catch (cause: Exception) {
            error(
                "The local backend is not answering on ${TestServer.host}:${TestServer.port} " +
                    "(${cause::class.simpleName}: ${cause.message}). " +
                    "Start it with ./scripts/run-local-backend.sh. " +
                    "This is not a test failure and says nothing about the code.",
            )
        }
        check(response.status == HttpStatusCode.NoContent) {
            "Local server fixture endpoint returned ${response.status}. " +
                "Start it with ./scripts/run-local-backend.sh."
        }
    }
}
