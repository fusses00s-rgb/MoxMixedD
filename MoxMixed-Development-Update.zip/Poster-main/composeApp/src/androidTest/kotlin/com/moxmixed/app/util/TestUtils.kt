package com.moxmixed.app.util

import androidx.compose.ui.test.*
import androidx.compose.ui.test.printToString
import androidx.compose.ui.test.junit4.AndroidComposeTestRule
import androidx.test.ext.junit.rules.ActivityScenarioRule
import com.moxmixed.app.MainActivity
import com.moxmixed.app.auth.InMemoryAuthTokenStorage
import com.moxmixed.app.ktor.KtorPostApi
import com.moxmixed.app.ktor.KtorUserApi
import com.moxmixed.app.ktor.createHttpClient
import com.moxmixed.app.model.Post
import com.moxmixed.app.repository.PostRepository
import com.moxmixed.app.repository.TagRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import com.moxmixed.app.ktor.KtorGroupApi

object TestUtils : KoinComponent {

    // Inject repositories through Koin
    private val postRepository: PostRepository by inject()
    private val tagRepository: TagRepository by inject()
    private val appPreferences: AppPreferences by inject()

    suspend fun seedPostAsSecondUser(post: Post) {
        val tokenStorage = InMemoryAuthTokenStorage()
        createHttpClient(TestServer.host, TestServer.port, authTokenStorage = tokenStorage).use { httpClient ->
            val userApi = KtorUserApi(httpClient, tokenStorage)
            check(userApi.authenticateUser("user2@example.com", "password123") != null)
            KtorPostApi(httpClient).addPost(post)
            userApi.logout()
        }
    }

    /** Removing a seeded post, as the author — the only person allowed to. */
    suspend fun deletePostAsSecondUser(post: Post) {
        val tokenStorage = InMemoryAuthTokenStorage()
        createHttpClient(TestServer.host, TestServer.port, authTokenStorage = tokenStorage).use { httpClient ->
            val userApi = KtorUserApi(httpClient, tokenStorage)
            check(userApi.authenticateUser("user2@example.com", "password123") != null)
            KtorPostApi(httpClient).removePost(post)
            userApi.logout()
        }
    }

    suspend fun joinGroupAsTestUser(inviteCode: String) {
        val tokenStorage = InMemoryAuthTokenStorage()
        createHttpClient(TestServer.host, TestServer.port, authTokenStorage = tokenStorage).use { httpClient ->
            val userApi = KtorUserApi(httpClient, tokenStorage)
            val user = userApi.authenticateUser("test@example.com", "password123")
            check(user != null)
            // The invite path, as the app uses it: joining by id is for public groups only.
            val result = KtorGroupApi(httpClient).joinWithInvite(user!!.guid, inviteCode)
            check(result == com.moxmixed.app.network.JoinResult.JOINED) { "could not join with $inviteCode: $result" }
            userApi.logout()
        }
    }

    /**
     * A group the test user owns, with the second user brought in as a
     * member — the shape the promote-to-admin controls need. Returns its id.
     * The fixture's group-a has no owner, so it grows no Manage panel; this one
     * does.
     */
    fun ownedGroupWithSecondMember(name: String): String = runBlocking {
        lateinit var groupId: String
        lateinit var code: String
        val ownerStorage = InMemoryAuthTokenStorage()
        createHttpClient(TestServer.host, TestServer.port, authTokenStorage = ownerStorage).use { httpClient ->
            val userApi = KtorUserApi(httpClient, ownerStorage)
            check(userApi.authenticateUser("test@example.com", "password123") != null)
            val group = checkNotNull(KtorGroupApi(httpClient).createGroup(name)) {
                "could not create the group"
            }
            groupId = group.id
            code = checkNotNull(KtorGroupApi(httpClient).createInvite(group.id)) {
                "could not create an invite"
            }
            userApi.logout()
        }
        val memberStorage = InMemoryAuthTokenStorage()
        createHttpClient(TestServer.host, TestServer.port, authTokenStorage = memberStorage).use { httpClient ->
            val userApi = KtorUserApi(httpClient, memberStorage)
            val member = checkNotNull(userApi.authenticateUser("user2@example.com", "password123"))
            check(
                KtorGroupApi(httpClient).joinWithInvite(member.guid, code) ==
                    com.moxmixed.app.network.JoinResult.JOINED
            ) {
                "the second user could not join"
            }
            userApi.logout()
        }
        groupId
    }

    suspend fun leaveGroupAsTestUser(groupId: String) {
        val tokenStorage = InMemoryAuthTokenStorage()
        createHttpClient(TestServer.host, TestServer.port, authTokenStorage = tokenStorage).use { httpClient ->
            val userApi = KtorUserApi(httpClient, tokenStorage)
            val user = userApi.authenticateUser("test@example.com", "password123")
            check(user != null)
            KtorGroupApi(httpClient).removeUserFromGroup(user!!.guid, groupId)
            userApi.logout()
        }
    }

    /**
     * [seeded] is what this test put on the backend as the second user. It is
     * removed again on the way out, whether the test passed or failed: the
     * backend is shared by every class in the run, so a post left behind turns
     * up in the next one's feed and in its counts.
     */
    fun runWrapped(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>,
        before: suspend (AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>) -> Unit = {},
        after: suspend (AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>) -> Unit = {},
        seeded: List<Post> = emptyList(),
        action: (AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>) -> Unit
    ) {
        try {
            applyServerFixtures()
            runBlocking {
                appPreferences.clear()
                // The database too, not just the caches. This used to be done
                // for us: signing out cleared it, and clearing preferences
                // looked like signing out. It no longer does — an app that
                // cannot reach the server must keep what it has — so a test
                // that wants a clean device now has to say so.
                postRepository.clearLocalPosts()
                tagRepository.clearCache()
            }
            runBlocking { before(composeTestRule) }
            action(composeTestRule)
        } catch (failure: Throwable) {
            // A failed test usually leaves the app somewhere `after` cannot
            // sign out from (a dialog, a sheet). Its own timeout must not
            // replace the failure that put us there.
            try {
                runBlocking { after(composeTestRule) }
            } catch (cleanup: Throwable) {
                failure.addSuppressed(cleanup)
            } finally {
                clearAppState(seeded)
            }
            throw failure
        }
        try {
            runBlocking { after(composeTestRule) }
        } finally {
            // Always clean up, even if after() fails
            clearAppState(seeded)
        }
    }

    /**
     * Clears this test's app state using repositories instead of direct
     * database access.
     *
     * What it removes from the backend is only what this test put there: the
     * posts it seeded and the posts the signed-in person wrote. It used to
     * delete every post it could see, which on a backend shared by the whole
     * run meant deleting the fixtures and whatever the next class had seeded.
     */
    private fun clearAppState(seeded: List<Post> = emptyList()) {
        runBlocking {
            try {
                val currentUserId = appPreferences.getUserId()

                // Clear preferences (logout user)
                appPreferences.clear()

                // Clear repository caches and underlying data
                postRepository.clearCache()
                // Tolerant: a post the test itself already removed is fine.
                seeded.forEach { post -> runCatching { deletePostAsSecondUser(post) } }
                currentUserId?.let { userId ->
                    postRepository.refreshMyPosts(userId)
                    postRepository.myPosts(userId)?.first().orEmpty()
                        .forEach { postRepository.deletePost(it) }
                    postRepository.getFavoritePosts()
                        .onSuccess { snapshot ->
                            snapshot.favoritePosts.forEach { post ->
                                postRepository.removeFavorite(userId, post.guid)
                            }
                        }
                }

                println("TestUtils: App state cleared successfully using repositories")
            } catch (e: Exception) {
                println("TestUtils: Error clearing app state: ${e.message}")
                // Don't throw - we want tests to continue even if cleanup partially fails
            }
        }
    }

    /**
     * Performs logout via UI navigation with fallback to programmatic logout
     */
    fun performLogout(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>
    ) {
        try {
            // Check if we're already on login screen
            if (composeTestRule.onAllNodesWithTag("login_field").fetchSemanticsNodes().isNotEmpty()) {
                return // Already logged out
            }

            // Try UI logout first
            performUILogout(composeTestRule)

        } catch (e: Throwable) { // ComposeTimeoutException extends Throwable, not Exception
            println("TestUtils: UI logout failed, falling back to programmatic logout: ${e.message}")
            // Fallback: Clear preferences programmatically
            performProgrammaticLogout(composeTestRule)
        }
    }

    /**
     * Performs logout via UI navigation
     */
    private fun performUILogout(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>
    ) {
        // Navigate to settings
        composeTestRule.onNodeWithTag("settings_tab").performClick()
        composeTestRule.waitUntil(timeoutMillis = 3000) {
            composeTestRule.onAllNodesWithTag("settings_screen").fetchSemanticsNodes().isNotEmpty()
        }

        // Click logout button, then confirm: signing out asks first now
        composeTestRule.onNodeWithTag("logout_button").performScrollTo().performClick()
        composeTestRule.waitUntil(timeoutMillis = 3000) {
            composeTestRule.onAllNodesWithTag("confirm_sign_out_button").fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.onNodeWithTag("confirm_sign_out_button").performClick()

        // Wait for login screen to appear
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("login_field").fetchSemanticsNodes().isNotEmpty()
        }
    }

    /**
     * Performs programmatic logout by clearing preferences through repository
     */
    private fun performProgrammaticLogout(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>
    ) {
        runBlocking { appPreferences.clear() }

        // Give the app a moment to react to the preferences change
        composeTestRule.waitForIdle()

        // Wait for login screen to appear
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("login_field").fetchSemanticsNodes().isNotEmpty()
        }
    }

    /**
     * Performs login with test credentials
     */
    fun performLogin(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>,
        email: String = "test@example.com",
        password: String = "password123"
    ) {
        // Wait for login screen to appear
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("login_field").fetchSemanticsNodes().isNotEmpty()
        }

        composeTestRule.onNodeWithTag("login_field").performTextInput(email)

        // Enter password (though it might not be used in the current implementation)
        composeTestRule.onNodeWithTag("password_field").performTextInput(password)

        // Click login button
        composeTestRule.onNodeWithTag("login_button").performClick()

        // Wait for login to complete and navigate to feed.
        //
        // Reported with what is on screen instead of a bare timeout: "the feed
        // did not appear" is the same message whether the password was wrong,
        // the backend was down, or a dialog is covering everything, and the
        // difference is exactly what somebody debugging needs.
        try {
            composeTestRule.waitUntil(timeoutMillis = 10000) {
                composeTestRule.onAllNodesWithTag("feed_screen").fetchSemanticsNodes().isNotEmpty()
            }
        } catch (timeout: Exception) {
            val loginError = composeTestRule.onAllNodesWithTag("login_error_message").fetchSemanticsNodes()
            error(
                "Signing in as $email never reached the feed. " +
                    (if (loginError.isNotEmpty()) "The screen shows a login error. " else "") +
                    "On screen:\n" + composeTestRule.onRoot().printToString(maxDepth = 12),
            )
        }
    }

    /** Performs registration through the real registration UI. */
    fun performRegistration(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>,
        name: String = "Test",
        surname: String = "User",
        email: String = "newuser@example.com",
        password: String = "password123",
        groupCode: String? = null
    ) {
        // Click register button
        composeTestRule.onNodeWithTag("register_button").performClick()
        composeTestRule.onNodeWithTag("register_name_field").performTextInput(name)
        composeTestRule.onNodeWithTag("register_surname_field").performTextInput(surname)
        composeTestRule.onNodeWithTag("register_email_field").performTextInput(email)
        composeTestRule.onNodeWithTag("register_password_field").performTextInput(password)
        composeTestRule.onNodeWithTag("register_password_repeat_field").performTextInput(password)
        groupCode?.let {
            composeTestRule.onNodeWithTag("register_group_code_field").performTextInput(it)
        }
        composeTestRule.onNodeWithTag("registration_submit_button").performClick()

        composeTestRule.waitUntil(timeoutMillis = 10_000) {
            composeTestRule.onAllNodesWithTag("feed_screen").fetchSemanticsNodes().isNotEmpty()
        }
    }

    /**
     * Navigates to settings screen
     */
    fun navigateToSettings(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>
    ) {
        composeTestRule.onNodeWithTag("settings_tab").performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("settings_screen").fetchSemanticsNodes().isNotEmpty()
        }
    }

    /**
     * Waits for a tag to exist, then asserts it.
     *
     * Screens here arrive after a network round trip, so asserting the instant
     * after navigating samples a tree that is still being built. That produced
     * failures that always passed in isolation — including the confusing
     * "found it in the unmerged tree" ones, which is what a half-composed
     * subtree looks like.
     */
    fun awaitTag(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>,
        tag: String,
        timeoutMillis: Long = 5000,
    ) {
        composeTestRule.waitUntil(timeoutMillis) {
            composeTestRule.onAllNodesWithTag(tag).fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.onNodeWithTag(tag).assertExists()
    }

    fun navigateToFavorites(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>
    ) {
        composeTestRule.onNodeWithTag("favourites_tab").performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("favourites_screen").fetchSemanticsNodes().isNotEmpty()
        }
    }

    /**
     * Waits for at least one node with the tag. [awaitTag] insists on exactly
     * one, which is right for a screen and wrong for a list of cards.
     */
    fun awaitAnyTag(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>,
        tag: String,
        timeoutMillis: Long = 10_000,
    ) {
        composeTestRule.waitUntil(timeoutMillis) {
            composeTestRule.onAllNodesWithTag(tag).fetchSemanticsNodes().isNotEmpty()
        }
    }

    fun navigateToHome(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>
    ) {
        composeTestRule.onNodeWithTag("feed_tab").performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("feed_screen").fetchSemanticsNodes().isNotEmpty()
        }
    }

    fun navigateToMyPosts(
        composeTestRule: AndroidComposeTestRule<ActivityScenarioRule<MainActivity>, MainActivity>
    ) {
        composeTestRule.onNodeWithTag("my_posts_tab").performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("my_posts_screen").fetchSemanticsNodes().isNotEmpty()
        }
    }
}
