package com.moxmixed.app

import androidx.compose.runtime.*
import org.jetbrains.compose.ui.tooling.preview.Preview
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import com.moxmixed.app.ui.MainScreen
import com.moxmixed.app.viewmodel.AccountViewModel
import com.moxmixed.app.viewmodel.PostsViewModel
import com.moxmixed.app.viewmodel.ThemeViewModel

// Helper class to access Koin dependencies
class AppDependencies : KoinComponent {
    val postsViewModel: PostsViewModel by inject()
    val accountViewModel: AccountViewModel by inject()
    val themeViewModel: ThemeViewModel by inject()
}

@Composable
@Preview
fun App(fixedTab: String? = null) {
    // Get dependencies from Koin
    val dependencies = remember { AppDependencies() }

    // Set up the main UI
    MainScreen(
        postsViewModel = dependencies.postsViewModel,
        userViewModel = dependencies.accountViewModel,
        themeViewModel = dependencies.themeViewModel,
        fixedTab = fixedTab,
    )
}
