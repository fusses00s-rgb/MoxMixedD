package com.moxmixed.app.di

import com.moxmixed.app.viewmodel.BookmarksViewModel
import com.moxmixed.app.viewmodel.FollowsViewModel
import com.moxmixed.app.notification.PushRegistrar
import com.moxmixed.app.viewmodel.NotificationsViewModel
import com.moxmixed.app.viewmodel.CommentsViewModel
import com.moxmixed.app.billing.SupportRepository
import com.moxmixed.app.di.AppConfig
import com.moxmixed.app.viewmodel.SupportViewModel
import org.koin.dsl.module
import com.moxmixed.app.viewmodel.AccountViewModel
import com.moxmixed.app.viewmodel.FavoritesViewModel
import com.moxmixed.app.viewmodel.PostsViewModel
import com.moxmixed.app.viewmodel.GroupViewModel
import com.moxmixed.app.viewmodel.FeedbackViewModel
import com.moxmixed.app.viewmodel.TagViewModel
import com.moxmixed.app.viewmodel.ThemeViewModel
import com.moxmixed.app.config.Features

fun viewModelModule() = module {
    single { SupportRepository(apiKey = get<AppConfig>().revenueCatApiKey, dispatchers = get()) }
    single {
        SupportViewModel(
            support = get(),
            session = get(),
            dispatchers = get(),
            demoPaywall = get<AppConfig>().demoPaywall,
        )
    }
    single {
        PostsViewModel(
            repository = get(),
            session = get(),
            dispatchers = get(),
            events = get(),
        )
    }
    single { AccountViewModel(get(), get(), get()) }
    single {
        FavoritesViewModel(
            repository = get(),
            session = get(),
            dispatchers = get()
        )
    }
    single { TagViewModel(get(), get()) }
    single { com.moxmixed.app.ui.images.PostImageLoader(get()) }
    single { GroupViewModel(get(), get(), get()) }
    // Gated where the only screen that resolves one is itself behind the flag.
    // FollowsViewModel, BookmarksViewModel and PushRegistrar are not: HomeScreen
    // and MainScreen inject them before any flag is looked at.
    if (Features.FEEDBACK) single { FeedbackViewModel(get(), get()) }
    if (Features.COMMENTS) single { CommentsViewModel(get(), get()) }
    if (Features.PUSH_NOTIFICATIONS) single { NotificationsViewModel(get(), get()) }
    single { FollowsViewModel(get(), get()) }
    single { BookmarksViewModel(get(), get()) }
    single { PushRegistrar(session = get(), notifications = get(), dispatchers = get()) }
    single { ThemeViewModel(get(), get()) }
}
