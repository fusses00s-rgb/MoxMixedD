package com.moxmixed.app.preview

import com.moxmixed.app.model.Feedback
import com.moxmixed.app.model.FeedbackStatus
import com.moxmixed.app.network.FeedbackApi

class FakeFeedbackApi : FeedbackApi {
    private val items = mutableListOf(
        Feedback(
            id = "1",
            message = "Could the feed remember where I scrolled to?",
            createdAt = "2026-09-05T10:00:00",
            response = "It does now — thank you for asking.",
            respondedAt = "2026-09-06T09:00:00",
            status = FeedbackStatus.ANSWERED,
        ),
        Feedback(
            id = "2",
            message = "A dark mode that follows the phone would be lovely.",
            createdAt = "2026-09-07T20:30:00",
        ),
    )

    override suspend fun submit(message: String): Boolean {
        items.add(0, Feedback(id = (items.size + 1).toString(), message = message, createdAt = "now"))
        return true
    }

    override suspend fun myFeedback(): List<Feedback> = items
}
