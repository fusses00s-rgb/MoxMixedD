package com.moxmixed.app.preview

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.moxmixed.app.cache.PostCache
import com.moxmixed.app.repository.FeedbackRepository
import com.moxmixed.app.repository.PostRepository
import com.moxmixed.app.repository.SessionRepository
import com.moxmixed.app.repository.TagRepository
import com.moxmixed.app.util.AppPreferences
import com.moxmixed.app.util.DispatcherProvider
import com.moxmixed.app.viewmodel.AccountViewModel
import com.moxmixed.app.viewmodel.FavoritesViewModel
import com.moxmixed.app.viewmodel.FeedbackViewModel
import com.moxmixed.app.viewmodel.PostsViewModel
import com.moxmixed.app.viewmodel.TagViewModel
import com.moxmixed.app.viewmodel.ThemeViewModel
import kotlinx.coroutines.Dispatchers

/**
 * The fake object graph every `@Preview` needs.
 *
 * Each preview used to assemble this by hand — nine copies of the same dozen
 * lines, which meant every constructor change was a nine-file edit and previews
 * silently drifted from how the app is actually wired.
 */
class PreviewGraph {
    val dispatchers = DispatcherProvider(main = Dispatchers.Default, io = Dispatchers.Default)
    val appPreferences = AppPreferences(FakePlatformDataStore())
    val userApi = FakeUserApi()
    val postApi = FakePostApi()
    val groupApi = FakeGroupApi()
    val tagApi = FakeTagApi()
    val feedbackApi = FakeFeedbackApi()

    val repository = PostRepository(
        postApi = postApi,
        cache = PostCache(),
        dispatchers = dispatchers,
    )
    val session = SessionRepository(userApi, appPreferences, dispatchers)

    val accountViewModel = AccountViewModel(session, dispatchers)
    val postsViewModel = PostsViewModel(repository, session, dispatchers)
    val favoritesViewModel = FavoritesViewModel(repository, session, dispatchers)
    val themeViewModel = ThemeViewModel(appPreferences, dispatchers)
    val tagViewModel = TagViewModel(TagRepository(tagApi, appPreferences), dispatchers)
    val feedbackViewModel = FeedbackViewModel(FeedbackRepository(feedbackApi, dispatchers), dispatchers)
}

/** Kept across recompositions so a preview does not rebuild its world on every frame. */
@Composable
fun rememberPreviewGraph(): PreviewGraph = remember { PreviewGraph() }
