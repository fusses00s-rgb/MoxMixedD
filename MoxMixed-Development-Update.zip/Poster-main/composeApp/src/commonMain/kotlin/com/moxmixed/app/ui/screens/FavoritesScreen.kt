package com.moxmixed.app.ui.screens

import com.moxmixed.app.ui.liquid.LocalBottomBarInset
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.moxmixed.app.theme.Spacing
import com.moxmixed.app.ui.components.EmptyState
import com.moxmixed.app.ui.components.PostCard
import com.moxmixed.app.ui.components.LargePageTitle
import com.moxmixed.app.ui.components.ScreenTopBar
import com.moxmixed.app.ui.components.SignedOutPlaceholder
import com.moxmixed.app.ui.components.rememberCollapseFraction
import com.moxmixed.app.theme.isApplePlatform
import com.moxmixed.app.ui.components.PostCardVariant
import com.moxmixed.app.ui.components.UndoSnackbar
import org.jetbrains.compose.resources.stringResource
import moxmixed.composeapp.generated.resources.Res
import moxmixed.composeapp.generated.resources.login
import moxmixed.composeapp.generated.resources.nav_favorites
import org.jetbrains.compose.ui.tooling.preview.Preview
import com.moxmixed.app.viewmodel.GroupViewModel
import com.moxmixed.app.viewmodel.nameOf
import org.koin.compose.koinInject
import com.moxmixed.app.viewmodel.AccountViewModel
import com.moxmixed.app.viewmodel.FavoritesViewModel
import moxmixed.composeapp.generated.resources.empty_favorites
import moxmixed.composeapp.generated.resources.empty_fav_action
import moxmixed.composeapp.generated.resources.empty_fav_body
import moxmixed.composeapp.generated.resources.empty_fav_title
import com.moxmixed.app.preview.rememberPreviewGraph
import moxmixed.composeapp.generated.resources.post_unfavorite
import kotlinx.datetime.toLocalDateTime
import kotlinx.datetime.TimeZone
import kotlinx.datetime.Clock
import com.moxmixed.app.model.Post
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.Icons
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.ExperimentalMaterial3Api
import com.moxmixed.app.ui.components.PeriodicRefresh

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    groupViewModel: GroupViewModel = koinInject(),
    onPostClick: (Post) -> Unit = {},
    onBrowseFeed: () -> Unit = {},
    favoritesViewModel: FavoritesViewModel = koinInject(),
    accountViewModel: AccountViewModel = koinInject()
) {
    val groupNames by groupViewModel.groups.collectAsState()
    val isLoggedIn by accountViewModel.isLoggedInState.collectAsState()
    val favorites by favoritesViewModel.state.collectAsState()
    val isRefreshing by favoritesViewModel.isRefreshing.collectAsState()
    val favoritePosts = favorites.posts


    // Also covers a post favorited on another device under the same account.
    PeriodicRefresh(key = isLoggedIn) {
        if (isLoggedIn) favoritesViewModel.loadFavorites()
    }

    // The large title lives as the first row of the list and slides away as it
    // scrolls; the compact title in the bar fades in once it is gone. iOS only —
    // Android keeps its single compact title.
    val listState = rememberLazyListState()
    // A fraction, not a flag: the large title fades out and the inline title in
    // over the first bit of scroll, so nothing clips or pops. 1 on Android,
    // which shows only the compact title.
    val collapseFraction = rememberCollapseFraction(listState)

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .testTag("favourites_screen")
        ) {
            ScreenTopBar(title = stringResource(Res.string.nav_favorites), titleAlpha = collapseFraction)
            PullToRefreshBox(
                isRefreshing = isRefreshing,
                onRefresh = { favoritesViewModel.refresh() },
                modifier = Modifier.fillMaxSize(),
            ) {
            Column(modifier = Modifier.fillMaxSize().padding(horizontal = Spacing.md)) {

            if (!isLoggedIn) {
                SignedOutPlaceholder(
                    "${stringResource(Res.string.login)} ${stringResource(Res.string.nav_favorites)}",
                )
            } else if (favoritePosts.isEmpty()) {
                EmptyState(
                    art = Res.drawable.empty_favorites,
                    title = stringResource(Res.string.empty_fav_title),
                    body = stringResource(Res.string.empty_fav_body),
                    actionLabel = stringResource(Res.string.empty_fav_action),
                    onAction = onBrowseFeed,
                    modifier = Modifier.testTag("empty_favourites_state"),
                )
            } else {
                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(Spacing.sm),
                    // Breathing room so the last card does not sit flush against
                    // the nav bar.
                    contentPadding = PaddingValues(bottom = Spacing.md + LocalBottomBarInset.current),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("favourites_list")
                ) {
                    if (isApplePlatform) {
                        item { LargePageTitle(stringResource(Res.string.nav_favorites), collapseFraction = collapseFraction) }
                    }
                    items(favoritePosts, key = { it.guid }) { post ->
                        PostCard(
                            onClick = { onPostClick(post) },
                            post = post,
                            variant = PostCardVariant.Liked,
                            groupName = groupNames.nameOf(post.group),
                            likeCount = favorites.countFor(post),
                            isLiked = true,
                            onToggleLike = { favoritesViewModel.toggleFavorite(post) },
                        )
                    }
                }
            }
            }
            }
        }

        // Undo Snackbar positioned at bottom
        UndoSnackbar(
            favoritesViewModel = favoritesViewModel,
            // Lift clear of the native iOS glass bar the list scrolls behind.
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = LocalBottomBarInset.current)
        )
    }
}

@Preview
@Composable
fun FavoritesScreenPreview() {
    val graph = rememberPreviewGraph()
    FavoritesScreen(
        favoritesViewModel = graph.favoritesViewModel,
        accountViewModel = graph.accountViewModel,
    )
}
