# MoxMixed — MVP implementation plan

## Product

MoxMixed is a creator-submission platform, not a general-purpose messenger. Viewers discover approved streamers and send them material for possible use on stream. Streamers review an inbox and update each submission's status. Only the configured main administrator may approve streamer applications or grant the streamer role.

## Roles and authority

- `VIEWER`: default role after successful registration. Can browse the public streamer directory, submit content, and view the status of their own submissions.
- `STREAMER_PENDING`: requested streamer access; cannot receive submissions until approved.
- `STREAMER`: can manage their public channel profile and review submissions addressed to them.
- `ADMIN`: server-configured main administrator. Can approve/reject streamer applications, suspend accounts, and review moderation events.

The app must never accept a role supplied by the client during registration. Role changes are server-side only. The admin account is bootstrapped from a verified email configured in the server environment; no public registration path creates an admin.

## MVP screens

1. Welcome / sign in / registration (email, username, password; password recovery by email).
2. Streamer directory with avatar cards and search by username or display name.
3. Streamer profile with channel description and a `Send a suggestion` action.
4. Submission composer: text, one or more links, image, or video; enforce file size and MIME allow-lists on the server.
5. My submissions: status timeline (`NEW`, `SEEN`, `ACCEPTED`, `DECLINED`).
6. Streamer inbox: filter and review submissions; status changes are recorded with timestamps.
7. Streamer application form and pending/approved/rejected state.
8. Admin review queue for streamer applications, with approve/reject actions and an audit log.

## Suggested server records

- `StreamerProfile(user_id UNIQUE, display_name, handle UNIQUE, description, avatar_upload_id, channel_url, approved_at, approved_by)`
- `StreamerApplication(id, user_id, channel_url, message, status, created_at, reviewed_at, reviewed_by, review_note)`
- `Submission(id, viewer_id, streamer_id, text, link_url, attachment_id, attachment_kind, status, created_at, updated_at, reviewed_at)`
- `ModerationAudit(id, actor_id, action, target_type, target_id, details_json, created_at)`

Foreign keys must reference existing accounts. Every read/write must enforce ownership on the server: viewers can only read their own submissions; streamers can only read submissions addressed to their own approved profile; only admins can decide applications.

## Upload safety

- Authenticate before upload; apply per-account rate limits and quotas.
- Allow only known image/video MIME types; verify file signatures rather than trusting the filename.
- Set maximum upload sizes and duration limits; reject executable and archive uploads.
- Store files outside the web root or in private object storage; serve with short-lived authorized URLs.
- Add reporting, retention/deletion policy, and moderation before public display.

## Current implementation boundary

The current source tree provides a Kotlin Multiplatform/Compose client, Ktor server, account authentication, image uploads, notifications, and an existing web admin area. The streamer directory, streamer approval workflow, video upload policy, and submission inbox described above are product work still to implement; this document is a specification, not a claim that those endpoints already exist.

## Build

Use `.github/workflows/build-moxmixed-apk.yml` to produce a debug APK. A real backend must be deployed and its hostname passed as the workflow's `server_host` input (or set as the repository variable `MOXMIXED_SERVER_HOST`). The default `moxmixed.example` value is deliberately only a placeholder; an APK built with it installs but cannot log in to a live service.
