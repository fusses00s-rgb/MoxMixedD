# MoxMixed server setup (before real APK testing)

The Android app is a remote client. A real public server must be running before registration, login, uploads, or streamer submissions can work. The APK workflow can build with a placeholder host for packaging checks, but that APK is not a working online service.

## Required deployment settings

Use a Linux host with Java 21 and persistent storage. Put a TLS reverse proxy (HTTPS) in front of the Ktor server and forward requests to its configured `PORT` (default `8080`). Keep the database and upload directory on persistent volumes; do not use an ephemeral container filesystem for user data.

Set these environment variables in the server's secret/configuration panel:

- `PORT=8080` — internal Ktor port, if the host does not provide one.
- `POSTER_JWT_SECRET` — long random secret; required outside development mode.
- `POSTER_ADMIN_ENABLED=true` — enables the existing web admin panel.
- `POSTER_ADMIN_EMAIL` — the email address of the owner account. Register this account first and verify its email; the server promotes that verified account on startup.
- `POSTER_ADMIN_SESSION_KEY` — random secret of at least 32 characters for admin browser sessions.
- `POSTER_BASE_URL` — public HTTPS base URL of the server.
- `POSTER_SAFETY_CONTACT` — monitored contact email for the required child-safety page.

Generate secrets with a trusted password manager or `openssl rand -base64 48`. Never commit secrets to GitHub or put them in the Android app.

## Upload storage

Configure the upload store using the environment variables documented in `server/src/main/kotlin/com/moxmixed/app/uploads/UploadStore.kt`. Mount its data directory persistently, restrict filesystem permissions, and enforce request-size limits at the reverse proxy as well as in Ktor. Do not expose the private storage directory as a static web directory.

## Android build

1. Deploy the server and confirm its public `/health` endpoint responds over HTTPS.
2. In GitHub, open **Settings → Secrets and variables → Actions → Variables** and add `MOXMIXED_SERVER_HOST` containing only the hostname (no `https://` and no path), or enter it in the workflow's `server_host` input.
3. Run **Actions → Build MoxMixed APK → Run workflow**.
4. Download the `MoxMixed-debug-apk` artifact from the successful run. The artifact includes a SHA-256 checksum file.
5. Install the APK on an Android phone and test registration, email verification, login, and uploads against the deployed host.

## Important product status

This deployment guide covers the existing Poster-derived Ktor foundation and its authentication/admin setup. It does not claim that MoxMixed-specific streamer profiles, applications, approval queue, or submission inbox have been implemented yet. Those features remain the next application-development milestone.
