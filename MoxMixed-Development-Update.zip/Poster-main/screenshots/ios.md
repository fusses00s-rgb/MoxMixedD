# iOS screenshots

Captured from the running app with demo data, in the default palette. How: `scripts/ios-screenshots.sh` on a simulator against the local backend; the app is driven by the XCUITest suite (docs/Screenshots.md).

[← README](../README.md) · other platforms:
[Android](android.md) · [iOS with the native bar turned off](ios-docked.md) · [iPad](ipad.md) · [Desktop (JVM)](desktop.md) · [Web (Kotlin/Wasm)](web.md) · 

## home

<table><tr><th>Light</th><th>Dark</th></tr><tr><td><img src="ios/light-01-home.png" width="280" alt="home, light"></td><td><img src="ios/dark-01-home.png" width="280" alt="home, dark"></td></tr></table>

## my posts

<table><tr><td><img src="ios/light-02-my-posts.png" width="280" alt="my posts"></td></tr></table>

## add post

<table><tr><td><img src="ios/light-03-add-post.png" width="280" alt="add post"></td></tr></table>

## delete confirmation

<table><tr><td><img src="ios/light-05-delete-confirmation.png" width="280" alt="delete confirmation"></td></tr></table>

## liked

<table><tr><td><img src="ios/light-06-liked.png" width="280" alt="liked"></td></tr></table>

## settings

<table><tr><th>Light</th><th>Dark</th></tr><tr><td><img src="ios/light-07-settings.png" width="280" alt="settings, light"></td><td><img src="ios/dark-07-settings.png" width="280" alt="settings, dark"></td></tr></table>

## groups

<table><tr><td><img src="ios/light-08-groups.png" width="280" alt="groups"></td></tr></table>

## post details

<table><tr><td><img src="ios/light-09-post-details.png" width="280" alt="post details"></td></tr></table>

## post comments

<table><tr><td><img src="ios/light-09b-post-comments.png" width="280" alt="post comments"></td></tr></table>

## support paywall

<table><tr><td><img src="ios/light-10-support-paywall.png" width="280" alt="support paywall"></td></tr></table>

## profile

<table><tr><td><img src="ios/light-11-profile.png" width="280" alt="profile"></td></tr></table>

## 00-login

<table><tr><td><img src="ios/00-login.png" width="280" alt="00-login"></td></tr></table>

## 00b-register

<table><tr><td><img src="ios/00b-register.png" width="280" alt="00b-register"></td></tr></table>

