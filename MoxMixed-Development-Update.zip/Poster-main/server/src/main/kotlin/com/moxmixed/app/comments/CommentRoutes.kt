package com.moxmixed.app.comments

import com.moxmixed.app.authenticatedUserId
import com.moxmixed.app.displayAuthor
import com.moxmixed.app.config.Features
import com.moxmixed.app.domain.validation.CommentRules
import com.moxmixed.app.model.AccountRepository
import com.moxmixed.app.model.ApiError
import com.moxmixed.app.model.CommentRequest
import com.moxmixed.app.model.PostsRepository
import io.ktor.http.HttpStatusCode
import io.ktor.http.HttpHeaders
import io.ktor.server.request.receive
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.route

/**
 * `/posts/{postId}/comments` — inside the bearer-authenticated `/posts` route.
 * A comment is visible to whoever may see the post ([PostsRepository.visiblePostById]
 * decides, as it does for the post itself), may be written by anybody who can
 * see it with a confirmed address, and removed by its author or the post's.
 */
fun Route.commentRoutes(
    comments: CommentsRepository,
    posts: PostsRepository,
    accounts: AccountRepository,
    /** Called with the post and the commenter after a comment is stored; the notifier listens. */
    onCommented: (post: com.moxmixed.app.model.Post, actor: String) -> Unit = { _, _ -> },
) {
    route("/{postId}/comments") {
        get {
            val viewer = call.authenticatedUserId()
            val postId = call.parameters["postId"].orEmpty()
            if (posts.visiblePostById(viewer, postId) == null) {
                call.respond(HttpStatusCode.NotFound)
                return@get
            }
            call.respond(comments.forPost(postId).map { it.withAuthor(accounts) })
        }

        post {
            val viewer = call.authenticatedUserId()
            val postId = call.parameters["postId"].orEmpty()
            val post = posts.visiblePostById(viewer, postId)
            if (post == null) {
                call.respond(HttpStatusCode.NotFound)
                return@post
            }
            if (Features.EMAIL_VERIFICATION_REQUIRED && accounts.userById(viewer)?.verifiedAt == null) {
                call.respond(
                    HttpStatusCode.Forbidden,
                    ApiError("Confirm your email address before commenting", ApiError.EMAIL_NOT_VERIFIED),
                )
                return@post
            }
            val text = runCatching { call.receive<CommentRequest>() }.getOrNull()?.text?.trim()
            if (text == null || !CommentRules.textValid(text)) {
                call.respond(HttpStatusCode.BadRequest, ApiError("A comment is 1 to ${CommentRules.TEXT_LIMIT} characters"))
                return@post
            }
            // A person writes a comment every few seconds at most. Without
            // this one account could fill a thread, and every comment is a
            // notification and a push at the post's author.
            if (!writeRate.take(viewer)) {
                call.response.headers.append(HttpHeaders.RetryAfter, "5")
                call.respond(HttpStatusCode.TooManyRequests, ApiError("Slow down a moment"))
                return@post
            }
            val added = comments.add(postId, viewer, text)
            onCommented(post, viewer)
            call.respond(added.withAuthor(accounts))
        }

        delete("/{commentId}") {
            val viewer = call.authenticatedUserId()
            val postId = call.parameters["postId"].orEmpty()
            val comment = comments.byId(call.parameters["commentId"].orEmpty())
            if (comment == null || comment.postGuid != postId) {
                call.respond(HttpStatusCode.NotFound)
                return@delete
            }
            val post = posts.postById(postId)
            // The post's author keeps their own thread: they may take down what
            // was said under their words, not only what they said themselves.
            if (comment.author != viewer && post?.author != viewer) {
                call.respond(HttpStatusCode.Forbidden)
                return@delete
            }
            comments.remove(comment.guid)
            call.respond(HttpStatusCode.NoContent)
        }
    }
}

private fun com.moxmixed.app.model.Comment.withAuthor(accounts: AccountRepository): com.moxmixed.app.model.Comment {
    val (name, photo) = accounts.displayAuthor(author) ?: return this
    return copy(authorName = name, authorPhoto = photo)
}

/**
 * Ten comments in hand, one back every three seconds.
 *
 * Deliberately generous: this is not a quota, it is the difference between a
 * person catching up on a thread and a script looping.
 */
private val writeRate = com.moxmixed.app.auth.WriteRate()
