package com.moxmixed.app

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import io.ktor.server.testing.ApplicationTestBuilder
import com.moxmixed.app.auth.GoogleVerifier
import com.moxmixed.app.model.AuthResponse
import com.moxmixed.app.model.RegisterRequest
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.KeyPairGenerator
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.time.Instant
import java.util.Date
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Deleting an account that has no password.
 *
 * `/delete-account` exists because Google Play requires deletion to be
 * reachable without the app. It asked for a password — and an account made
 * through a provider never has one a person could type, because
 * `signInWithProvider` stores a hash of a random UUID so the column is not
 * empty. Everybody who signed in with Google was told their details did not
 * match, which was true and useless, and the requirement was not actually met
 * for them.
 */
class DeleteAccountSocialTest {

    private val keys = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
    private val publicKey = keys.public as RSAPublicKey
    private val privateKey = keys.private as RSAPrivateKey
    private val otherKeys = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()

    private val now: Instant = Instant.now()

    private fun token(
        email: String = "member@example.com",
        subject: String = "google-subject-1",
        audience: String = CLIENT_ID,
        emailVerified: Boolean = true,
        expiresAt: Instant = now.plusSeconds(600),
        signWith: RSAPrivateKey = privateKey,
        // The page mints a nonce per render and posts the value back with the
        // token; these tests do the same with a fixed pair.
        nonce: String? = com.moxmixed.app.auth.nonceHash(NONCE),
    ): String = JWT.create()
        .withKeyId("key-1")
        .withAudience(audience)
        .withIssuer("https://accounts.google.com")
        .withSubject(subject)
        .withClaim("email", email)
        .apply { nonce?.let { withClaim("nonce", it) } }
        .withClaim("email_verified", emailVerified)
        .withExpiresAt(Date.from(expiresAt))
        .sign(Algorithm.RSA256(null, signWith))

    @Test
    fun aGoogleTokenDeletesTheAccountItBelongsTo() = withGoogle {
        val user = register("member@example.com")

        val response = deleteWith(credential = token())

        assertEquals(HttpStatusCode.OK, response.first, response.second)
        assertNull(
            accountsRepository().userById(user.user.guid),
            "the account is still there",
        )
    }

    /**
     * The tick is the "are you sure", and it guards the token as it guards the
     * password. A page that deletes on a button press because the credential
     * happened to be valid has skipped the only question it asks.
     */
    @Test
    fun anUntickedBoxDeletesNothing() = withGoogle {
        val user = register("member@example.com")

        val response = deleteWith(credential = token(), confirm = false)

        assertEquals(HttpStatusCode.BadRequest, response.first)
        assertTrue(
            accountsRepository().userById(user.user.guid) != null,
            "an unconfirmed request deleted the account anyway",
        )
    }

    /**
     * A token for somebody with no account here deletes nothing and says the
     * same thing a wrong password says.
     *
     * Anything else would make this page a way of asking whether an address has
     * an account — which is the same reason the password path has one message
     * for a wrong address and a wrong password alike.
     */
    @Test
    fun aTokenForAStrangerIsRefusedLikeAWrongPassword() = withGoogle {
        register("member@example.com")

        val stranger = deleteWith(credential = token(email = "nobody@example.com", subject = "other"))
        val wrongPassword = client.post("/delete-account") {
            contentType(ContentType.Application.FormUrlEncoded)
            setBody("email=member@example.com&password=wrong&confirm=on")
        }

        assertEquals(HttpStatusCode.Unauthorized, stranger.first)
        assertEquals(HttpStatusCode.Unauthorized, wrongPassword.status)
        // Compared with the nonce taken out: it is minted fresh on every
        // render and says nothing about which of the two failed, so two pages
        // that differ only there are the same page as far as a caller
        // learning something is concerned.
        assertEquals(
            withoutNonce(wrongPassword.bodyAsText()),
            withoutNonce(stranger.second),
            "a stranger's token was distinguishable from a wrong password",
        )
    }

    private fun withoutNonce(page: String): String =
        page.replace(Regex("[A-Za-z0-9_-]{43}"), "<nonce>")

    /** Every rule the verifier enforces for signing in still holds here. */
    @Test
    fun aTokenThatFailsVerificationDeletesNothing() = withGoogle {
        val user = register("member@example.com")

        val forged = deleteWith(credential = token(signWith = otherKeys.private as RSAPrivateKey))
        val expired = deleteWith(credential = token(expiresAt = now.minusSeconds(60)))
        val unverified = deleteWith(credential = token(emailVerified = false))
        val someoneElsesApp = deleteWith(credential = token(audience = "another-app.apps.googleusercontent.com"))

        listOf(forged, expired, unverified, someoneElsesApp).forEach {
            assertEquals(HttpStatusCode.Unauthorized, it.first)
        }
        assertTrue(
            accountsRepository().userById(user.user.guid) != null,
            "a token that should not verify deleted the account",
        )
    }

    /** The button is drawn, and the note about resetting a password is there. */
    @Test
    fun thePageOffersTheWayInForAnAccountWithNoPassword() = withGoogle {
        val page = client.get("/delete-account").bodyAsText()

        assertTrue(page.contains("accounts.google.com/gsi/client"), "no Google button on the page")
        assertTrue(page.contains(CLIENT_ID), "the button was drawn without a client id")
        assertTrue(page.contains("Continue with Apple"), "no Apple button on the page")
        assertTrue(page.contains("Reset your password"), "no way out for somebody stuck")
    }

    /** Russian gets the same page. */
    @Test
    fun theRussianPageSaysTheSameThings() = withGoogle {
        val page = client.get("/delete-account") { header("Accept-Language", "ru") }.bodyAsText()

        assertTrue(page.contains("Google"), "no Google button on the Russian page")
        assertTrue(page.contains("Продолжить с Apple"), "the Apple button was left in English")
    }

    // — helpers —

    private fun accountsRepository() = com.moxmixed.app.model.AccountLocalRepository(testDatabase())

    private suspend fun ApplicationTestBuilder.deleteWith(
        credential: String,
        confirm: Boolean = true,
    ): Pair<HttpStatusCode, String> {
        val body = buildString {
            append("credential=").append(credential)
            append("&nonce=").append(NONCE)
            if (confirm) append("&confirm=on")
        }
        val response = client.post("/delete-account") {
            contentType(ContentType.Application.FormUrlEncoded)
            setBody(body)
        }
        return response.status to response.bodyAsText()
    }

    private suspend fun ApplicationTestBuilder.register(email: String): AuthResponse {
        val response = client.post("/auth/register") {
            contentType(ContentType.Application.Json)
            setBody(Json.encodeToString(RegisterRequest("Some", "Body", email, "password123")))
        }
        assertEquals(HttpStatusCode.OK, response.status)
        return Json.decodeFromString(response.bodyAsText())
    }

    private companion object {
        const val CLIENT_ID = "poster.apps.googleusercontent.com"
    }

    /** The shared server, checking tokens against this suite's key and drawing the button for its client id. */
    private fun withGoogle(block: suspend ApplicationTestBuilder.(TestServer) -> Unit) =
        withServer(
            verifiers = listOf(GoogleVerifier(audience = CLIENT_ID, keyFor = { publicKey })),
            googleClientId = CLIENT_ID,
            block = block,
        )

    /** The value behind the nonce in the tokens these tests mint. */
    private val NONCE = "a-value-only-this-page-knows"
}
