package com.moxmixed.app.di

import com.moxmixed.app.util.PlatformDataStore
import com.moxmixed.app.util.PlatformDataStoreImpl
import com.moxmixed.app.auth.AndroidAuthTokenStorage
import com.moxmixed.app.auth.AuthTokenStorage
import com.moxmixed.app.crash.CrashStore
import com.moxmixed.app.crash.FileCrashStore
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.Module
import org.koin.dsl.module

actual fun platformModule(): Module = module {
    single<PlatformDataStore> { PlatformDataStoreImpl(androidContext()) }
    single<AuthTokenStorage> { AndroidAuthTokenStorage(androidContext()) }
    single<CrashStore> { FileCrashStore(androidContext()) }
}
