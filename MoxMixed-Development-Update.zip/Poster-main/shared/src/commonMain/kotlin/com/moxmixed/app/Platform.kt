package com.moxmixed.app

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform