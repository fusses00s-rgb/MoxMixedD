package com.moxmixed.app.di

import com.moxmixed.app.ktor.KtorBookmarkApi
import com.moxmixed.app.network.BookmarkApi
import com.moxmixed.app.ktor.KtorFollowApi
import com.moxmixed.app.network.FollowApi
import com.moxmixed.app.repository.NotificationRepository
import com.moxmixed.app.ktor.KtorNotificationApi
import com.moxmixed.app.network.NotificationApi
import com.moxmixed.app.repository.CommentRepository
import com.moxmixed.app.ktor.KtorCommentApi
import com.moxmixed.app.network.CommentApi
import com.moxmixed.app.cache.PostCache
import com.moxmixed.app.db.DatabaseDriverFactory
import com.moxmixed.app.db.DatabaseManager
import com.moxmixed.app.ktor.KtorGroupApi
import com.moxmixed.app.ktor.KtorEventApi
import com.moxmixed.app.ktor.KtorFeedbackApi
import com.moxmixed.app.ktor.KtorPostApi
import com.moxmixed.app.ktor.KtorConfigApi
import com.moxmixed.app.ktor.KtorTagsApi
import com.moxmixed.app.ktor.KtorUserApi
import com.moxmixed.app.ktor.createHttpClient
import com.moxmixed.app.network.GroupApi
import com.moxmixed.app.network.EventApi
import com.moxmixed.app.network.FeedbackApi
import com.moxmixed.app.network.PostApi
import com.moxmixed.app.crash.CrashUploader
import com.moxmixed.app.network.ConfigApi
import com.moxmixed.app.network.TagApi
import com.moxmixed.app.network.UserApi
import com.moxmixed.app.repository.FeedbackRepository
import com.moxmixed.app.repository.PostRepository
import com.moxmixed.app.telemetry.EventReporter
import com.moxmixed.app.repository.TagRepository
import com.moxmixed.app.repository.PostLocalStore
import com.moxmixed.app.repository.SessionRepository
import com.moxmixed.app.util.AppPreferences
import com.moxmixed.app.util.DispatcherProvider
import com.moxmixed.app.auth.AuthTokenStorage
import com.moxmixed.app.config.Features
import kotlinx.coroutines.Dispatchers
import org.koin.core.module.Module
import org.koin.dsl.module

// Configuration class to hold build variant specific settings
data class AppConfig(
    val serverHost: String,
    val serverPort: Int,
    val serverScheme: String = "http",
    /**
     * Keep the refresh token in a cookie the page's script cannot read.
     *
     * Set by the web build, and only when the API is the origin the page came
     * from: the cookie is SameSite=Strict, so a web app hosted elsewhere would
     * never receive it. The apps do not use it — they have a keystore and a
     * keychain, which is better than a cookie.
     */
    val cookieSession: Boolean = false,
    /**
     * The RevenueCat public SDK key, or blank for a build with no billing.
     *
     * Blank is an ordinary state, not a misconfiguration: the test flavor ships
     * without one on purpose, and support is simply unavailable there.
     */
    val revenueCatApiKey: String = "",
    /**
     * The Google Web OAuth client id, or blank for a build without Google
     * sign-in. Blank hides the button rather than offering one that cannot work.
     */
    val googleClientId: String = "",
    /**
     * The Apple Services ID, the OAuth client id for the Android browser flow.
     * Blank hides the Apple button on Android. iOS signs in natively and needs
     * nothing here — its token audience is the bundle id.
     */
    val appleServiceId: String = "",
    /**
     * Show the support paywall with placeholder tiers even without a billing key,
     * for screenshots before the store account exists. Never set in a shipped
     * build: taps buy nothing, the tiers are illustrative, and the switch is only
     * turned on by the screenshot capture.
     */
    val demoPaywall: Boolean = false,
    /**
     * The build label ("1.0 (321)"), attached to diagnostic events so a
     * misbehaviour can be tied to a build. Blank when a platform did not supply
     * one; harmless, just an empty column on those events.
     */
    val appVersion: String = "",
    /** Firebase project values for FCM on Android (`posterFirebase*` Gradle properties); blank = no push. */
    val firebaseProjectId: String = "",
    val firebaseAppId: String = "",
    val firebaseApiKey: String = "",
    val firebaseSenderId: String = "",
)

// Platform-specific module
expect fun platformModule(): Module

// Database module
fun databaseModule(databaseDriverFactory: DatabaseDriverFactory) = module {
    single { databaseDriverFactory }
    single { DatabaseManager(get()) }
}

// Shared module with common dependencies
fun sharedModule(appConfig: AppConfig) = module {
    // Make AppConfig available for injection
    single { appConfig }

    // API clients - pass server configuration
    single {
        createHttpClient(
            serverHost = appConfig.serverHost,
            serverPort = appConfig.serverPort,
            serverScheme = appConfig.serverScheme,
            authTokenStorage = get(),
            cookieSession = appConfig.cookieSession,
        )
    }

    // Cache
    single { PostCache() }

    // Session: who is signed in, shared by the account and favorites screens
    single {
        SessionRepository(
            userApi = get(),
            appPreferences = get(),
            dispatchers = get(),
            restoreFromPlatform = appConfig.cookieSession,
        )
    }

    // Preferences
    // PlatformDataStore is provided in platform-specific modules
    single { AppPreferences(get()) }

    // Coroutine dispatchers shared across repositories and view models
    single {
        DispatcherProvider(
            main = Dispatchers.Main,
            io = Dispatchers.Default
        )
    }

    // APIs
    // Original API (non-cached)
    single<PostApi> { KtorPostApi(get()) }
    single<UserApi> {
        KtorUserApi(get(), get())
    }

    single<TagApi> { KtorTagsApi(get()) }

    single<ConfigApi> { KtorConfigApi(get()) }

    single { CrashUploader(store = get(), httpClient = get()) }

    single<GroupApi> {
        KtorGroupApi(get())
    }

    // Only bound where something can ask for them. The rest stay unconditional
    // because a screen resolves them before it checks the flag — see
    // HomeScreen (follows/bookmarks) and MainScreen (PushRegistrar).
    if (Features.COMMENTS) {
        single<CommentApi> { KtorCommentApi(get()) }
        single { CommentRepository(api = get(), dispatchers = get()) }
    }
    if (Features.FEEDBACK) {
        single<FeedbackApi> { KtorFeedbackApi(get()) }
        single { FeedbackRepository(feedbackApi = get(), dispatchers = get()) }
    }
    single<FollowApi> { KtorFollowApi(get()) }
    single<BookmarkApi> { KtorBookmarkApi(get()) }
    single<NotificationApi> { KtorNotificationApi(get()) }
    single { NotificationRepository(api = get(), preferences = get(), dispatchers = get()) }

    single<EventApi> { KtorEventApi(get()) }
    single { EventReporter(api = get(), preferences = get(), appVersion = appConfig.appVersion, dispatchers = get()) }

    // Repositories (singletons)
    single { PostLocalStore(databaseManager = get(), dispatchers = get()) }

    single {
        PostRepository(
            postApi = get(),
            cache = get(),
            dispatchers = get(),
            localStore = get(),
        )
    }

    single {
        TagRepository(
            tagApi = get(),
            appPreferences = get(),
        )
    }
}
