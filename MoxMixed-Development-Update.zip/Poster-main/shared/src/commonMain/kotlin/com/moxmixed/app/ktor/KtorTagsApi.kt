package com.moxmixed.app.ktor

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get
import com.moxmixed.app.model.Tag
import com.moxmixed.app.network.TagApi

/**
 * Implementation of TagApi that uses Ktor HTTP client to make requests to the server.
 */
class KtorTagsApi(private val httpClient: HttpClient) : TagApi {
    override suspend fun getAllTags(): List<Tag> = httpClient.get("tags").body()
}