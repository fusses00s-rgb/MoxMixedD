package com.moxmixed.app.network

import com.moxmixed.app.model.AppEvent

/** Sending a diagnostic event to the server. Best-effort — a drop is acceptable. */
interface EventApi {
    suspend fun send(event: AppEvent): Boolean
}
