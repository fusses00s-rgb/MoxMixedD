package com.moxmixed.app.network

import com.moxmixed.app.model.Tag

/**
 * Interface for tag-related operations.
 * This is used by the application to interact with the backend.
 */
interface TagApi {
    /**
     * Gets all tags.
     */
    suspend fun getAllTags(): List<Tag>
}