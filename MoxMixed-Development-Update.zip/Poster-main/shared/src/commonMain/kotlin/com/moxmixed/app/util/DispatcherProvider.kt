package com.moxmixed.app.util

import kotlinx.coroutines.CoroutineDispatcher

/**
 * Simple holder for coroutine dispatchers used across repositories and view models.
 */
data class DispatcherProvider(
    val main: CoroutineDispatcher,
    val io: CoroutineDispatcher
)
