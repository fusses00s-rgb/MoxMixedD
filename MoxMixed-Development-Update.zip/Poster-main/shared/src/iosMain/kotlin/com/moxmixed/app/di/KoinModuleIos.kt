package com.moxmixed.app.di

import com.moxmixed.app.util.PlatformDataStore
import com.moxmixed.app.util.PlatformDataStoreImpl
import com.moxmixed.app.auth.AuthTokenStorage
import com.moxmixed.app.auth.IosAuthTokenStorage
import com.moxmixed.app.crash.CrashStore
import com.moxmixed.app.crash.FileCrashStore
import org.koin.core.module.Module
import org.koin.dsl.module

actual fun platformModule(): Module = module {
    single<PlatformDataStore> { PlatformDataStoreImpl() }
    single<AuthTokenStorage> { IosAuthTokenStorage() }
    single<CrashStore> { FileCrashStore() }
}
