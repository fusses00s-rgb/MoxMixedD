package com.moxmixed.app.di

import com.moxmixed.app.util.PlatformDataStore
import com.moxmixed.app.util.PlatformDataStoreImpl
import com.moxmixed.app.auth.AuthTokenStorage
import com.moxmixed.app.auth.InMemoryAuthTokenStorage
import com.moxmixed.app.crash.CrashStore
import com.moxmixed.app.model.CrashReport
import org.koin.core.module.Module
import org.koin.dsl.module

actual fun platformModule(): Module = module {
    single<PlatformDataStore> { PlatformDataStoreImpl() }
    single<AuthTokenStorage> { InMemoryAuthTokenStorage() }
    // Nothing to store: the JVM installs no crash handler (CrashReporter.jvm.kt),
    // so nothing ever writes one. Bound anyway because CrashUploader is in the
    // shared graph and would otherwise fail to resolve on desktop.
    single<CrashStore> {
        object : CrashStore {
            override fun save(report: CrashReport) = Unit
            override fun pending(): CrashReport? = null
            override fun clear() = Unit
        }
    }
}
