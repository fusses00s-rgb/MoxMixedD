# MoxMixed username-only authentication update

This update aligns the existing Android registration form (nickname + password + repeat password) with the Ktor server.

## Authentication behavior

- New registrations may send an empty `email` field. The server stores a private, non-deliverable key of the form `<lowercase-nickname>@users.moxmixed.invalid` because the current account schema still requires a unique email-shaped value.
- The nickname remains the public account name. The generated `.invalid` address is not a real mailbox and must not be used for email delivery.
- Login accepts either a legacy email address or a nickname. Nickname lookup is case-insensitive.
- Email verification is already disabled in `poster.properties` (`feature.emailVerificationRequired=false`); the registration route now also avoids attempting to send a verification message when that feature is disabled.
- Registration throttling is keyed by the nickname when the client sends no email, avoiding all email-less signups sharing an empty throttle key.

## Limitations to address later

- Accounts created with nickname-only registration cannot use email-based password reset until an email recovery method is added (for example, recovery codes or an optional verified email).
- Existing accounts registered with a real email can continue to sign in using that email. Their existing password and account data are not migrated.
- This change does not migrate SQLite to PostgreSQL. The backend still needs persistent storage or a separate PostgreSQL implementation before using an ephemeral free hosting filesystem for production data.

## Branding

The supplied MoxMixed pug-M image replaces the Android launcher icon assets and the shared app mark used on the login / welcome screens.
